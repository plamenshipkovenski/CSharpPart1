﻿using System;

class AssignHexToChar
{
    //http://msdn.microsoft.com/en-us/library/x9h8tsay(v=vs.71).aspx

    static void Main()
    {
        char ch;
        ch = '\x0048';
        Console.WriteLine(ch);
    }
}
