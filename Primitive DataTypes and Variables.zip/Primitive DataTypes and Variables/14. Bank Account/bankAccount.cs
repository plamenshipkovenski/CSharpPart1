﻿using System;

class BankAccount
{
    static void Main()
    {
        string firstName = "go6o";
        string secondName = "pe6ev";
        string pause = " ";
        string holderName = string.Concat(firstName, pause, secondName);

        decimal balance = new decimal();

        string bankName = "";
        string iBAN = "";
        string bICcode = "";

        long creditCardNumber1 = 9999999999999991;
        long creditCardNumber2 = 9999999999999992;
        long creditCardNumber3 = 9999999999999993;

    }
}
