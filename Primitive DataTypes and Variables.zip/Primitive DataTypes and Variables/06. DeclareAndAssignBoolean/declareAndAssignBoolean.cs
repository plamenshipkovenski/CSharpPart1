﻿using System;

class DeclareAndAssignBoolean
{
    static void Main()
    {
        bool isFemale;
        isFemale = false;    }
}
