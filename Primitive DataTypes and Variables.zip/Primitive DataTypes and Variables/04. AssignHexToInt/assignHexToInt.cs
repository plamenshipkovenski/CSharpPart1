﻿using System;

class AssignHexToInt
{
              //C# convert integer to hex and back again : http://stackoverflow.com/questions/1139957/c-sharp-convert-integer-to-hex-and-back-again
    //   ===> //C#: assign 0xFFFFFFFF to int : http://stackoverflow.com/questions/6797409/c-assign-0xffffffff-to-int
    static void Main()
    {
        int i = (int)0xFE;
        Console.WriteLine(i);
    }
}
